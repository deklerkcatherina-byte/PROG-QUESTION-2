import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

public class ProductApp extends JFrame {

    JTextField txtCustomer;
    JTextField txtPrice;
    JComboBox<String> cmbProduct;
    JButton btnProcess;

    public ProductApp() {

        setTitle("Product App");
        setSize(500, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2, 10, 10));

        // Menu
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");

        fileMenu.add(exitItem);
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);

        // Customer name
        add(new JLabel("Customer Name:"));
        txtCustomer = new JTextField();
        add(txtCustomer);

        // Product selection
        add(new JLabel("Select Product:"));

        String[] products = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        cmbProduct = new JComboBox<>(products);
        add(cmbProduct);

        // Price
        add(new JLabel("Enter Price:"));
        txtPrice = new JTextField();
        add(txtPrice);

        // Process button
        add(new JLabel(""));
        btnProcess = new JButton("PROCESS");
        add(btnProcess);

        // Button actions
        btnProcess.addActionListener(e -> processSale());

        processItem.addActionListener(e -> processSale());

        clearItem.addActionListener(e -> clearForm());

        exitItem.addActionListener(e -> System.exit(0));

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void processSale() {

        String customer = txtCustomer.getText();
        String product = cmbProduct.getSelectedItem().toString();

        if (customer.isEmpty() || txtPrice.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter all details.");
            return;
        }

        try {
            double price = Double.parseDouble(txtPrice.getText());

            if (price < 0) {
                JOptionPane.showMessageDialog(this, "Enter a valid price.");
                return;
            }

            ProductCalculations calculations =
                    new ProductCalculations(price);

            double vat = calculations.GetVat();
            double commission = calculations.GetCommission();
            double total = calculations.GetTotal();

            // Save information to data.txt
            FileWriter file = new FileWriter("data.txt", true);
            PrintWriter output = new PrintWriter(file);

            output.println("DATA LOG");
            output.println("****************************");
            output.println("Customer Name: " + customer);
            output.println("Product: " + product);
            output.println("VAT: R " + vat);
            output.println("COMMISSION: R " + commission);
            output.println("TOTAL: R " + total);
            output.println("****************************");

            output.close();

            // Display results
            JOptionPane.showMessageDialog(this,
                    "Customer Name: " + customer
                    + "\nProduct: " + product
                    + "\nVAT: R " + vat
                    + "\nCOMMISSION: R " + commission
                    + "\nTOTAL: R " + total);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid price.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving the file.");
        }
    }

    public void clearForm() {
        txtCustomer.setText("");
        txtPrice.setText("");
        cmbProduct.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        new ProductApp();
    }
}